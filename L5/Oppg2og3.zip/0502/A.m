function A = A(phi)
    A = [cos(phi) -sin(phi);sin(phi) cos(phi)];
end

