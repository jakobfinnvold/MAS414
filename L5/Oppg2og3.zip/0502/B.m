function B = B(phi)
    B = [-sin(phi) -cos(phi); cos(phi) -sin(phi)]; 
end

